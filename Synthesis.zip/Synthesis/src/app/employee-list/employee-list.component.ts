import { Component, OnInit } from '@angular/core';
import { EmployeesService } from '../employees.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {
  emp: any;
  constructor(private data:EmployeesService) { }

  ngOnInit() {
    this.data.getEmployees().subscribe(data=>{
      this.emp = data;
      console.log(this.data);
    });
  }




}
