import { Component, OnInit } from '@angular/core';
//import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';
import { User } from  '../user';
import { AuthService } from  '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  //userName: any;
  loginForm: FormGroup;
  isSubmitted  =  false;

userList: Array<any> = [
    {
      username: "abcd",
      password: "12345"    
    },
   
    
  ]

  
  constructor(private authService: AuthService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm  =  this.formBuilder.group({
      username: ['', Validators.required],
        password: ['', Validators.required]
    });
}

get formControls() { return this.loginForm.controls; }

login(){
  //debugger;
  console.log(this.loginForm.value);
  this.isSubmitted = true;
  if(this.loginForm.invalid){
    return;
  }
localStorage.setItem('test', JSON.stringify(this.loginForm.value));

    for (let i = 0; i < this.userList.length; i++) {
    if (this.loginForm.value.username == this.userList[i]['username'] && this.loginForm.value.password == this.userList[i]['password']) {
     // this.dashboard = true;
      this.userName = this.loginForm.value.username;
      this.router.navigateByUrl('/addEmployee');
    }

      else{
       // this._flashMessagesService.show('Username or Password Incorrect', { cssClass: 'alert' } );
       // this.login.reset()
      }
        
    
  }


  // if(this.loginForm.controls.username.value==this.username && this.loginForm.controls.password.value==this.password){
  //   this.router.navigateByUrl('/addEmployee');
  // }
  // this.authService.login(this.loginForm.value);
  // this.router.navigateByUrl('/addEmployee');
}
 }
 